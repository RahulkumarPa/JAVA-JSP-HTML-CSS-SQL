
public class LogicalExpression {

}
