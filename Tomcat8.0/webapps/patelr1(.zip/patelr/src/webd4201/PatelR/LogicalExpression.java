package webd4201.PatelR;

public class LogicalExpression 
{
    public long minimum_id =1111111000;
    public long miaximum_id = 999999999;
}
